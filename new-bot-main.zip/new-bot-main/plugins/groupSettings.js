let groupsettings = async(q , conn, M) => {
if (!q) return conn.send2Button(M.chat, '*Get to Open/Close Group!!*', "©Senkuu", "</Open", `!group open`, "</Close", `!group close`, M)
if (q === 'open'){
await conn.groupSettingUpdate(M.chat, 'not_announcement')
M.reply('Done Open Group!!')
} else if (q === 'close'){
await conn.groupSettingUpdate(M.chat, 'announcement')
M.reply('Done Close Group!!')
} else {
conn.send2Button(M.chat, '*Get to Open/Close Group!!*', "©Senkuu", "</Open", `!group open`, "</Close", `!group close`, M)
}
}

module.exports = groupsettings
