let fs = require('fs')
let setting = JSON.parse(fs.readFileSync('./config.json'))

let modeself = async(textImg) => {
setting.Mode = 'Self'
textImg('Done..')
}

module.exports = modeself
