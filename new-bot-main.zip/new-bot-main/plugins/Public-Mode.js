let fs = require('fs')
let setting = JSON.parse(fs.readFileSync('./config.json'))

let modepublic = async(textImg) => {
setting.Mode = 'Public'
textImg('Done..')
}

module.exports = modepublic
