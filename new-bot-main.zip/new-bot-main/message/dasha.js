"use strict";

require('./config')

//Module
const {
default: makeWASocket,
WASocket, 
AuthenticationState,
WAMessage, 
Contact, 
areJidsSameUser,
SocketConfig, 
DisconnectReason, 
BaileysEventMap,
GroupMetadata,
AnyMessageContent,
MessageType,
MiscMessageGenerationOptions,
BufferJSON,
delay,
proto,
useSingleFileAuthState,
downloadContentFromMessage,
WAMessageStubType,
generateWAMessage,
generateWAMessageFromContent
} = require('@adiwajshing/baileys-md')
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const { fromBuffer } = require('file-type')
const path = require('path')
const PhoneNumber = require('awesome-phonenumber')
const moment = require("moment-timezone");
const { exec, spawn } = require("child_process");
const hx = require('hxz-api');
const xfar = require('xfarr-api');
const axios = require('axios')
const speed = require('performance-now')
const os = require('os')
const { performance } = require('perf_hooks')
const ffmpeg = require('fluent-ffmpeg')
const yts = require('yt-search')
const imgbb = require('imgbb-uploader');
const fetch = require('node-fetch')

 
//Library
const { color, bgcolor } = require("../lib/color");
const { smsg, formatp, getBuffer, fetchJson, fetchText, getRandom, getGroupAdmins, runtime, sleep , tanggal, clockString} = require("../lib/myfunc");
const skrep = require('../lib/scrape')
const { yta, ytv, upload , youtube} = require("../lib/ytdl");
//const { servers, yta, ytv } = require('../lib/y2mate')
const { UploadFileUgu, webp2mp4File, TelegraPh } = require('../lib/uploader')

moment.tz.setDefault("Asia/Jakarta").locale("id");
 
module.exports = async(dasha, msg, m, M, help, setting) => {
try {
let { ownerNumber, botName } = setting
let timeout = 60000
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('DD/MM/YY HH:mm:ss z')
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
//const fromMe = msg.key.fromMe ? true : false
const from = msg.key.remoteJid
//const type = Object.keys(msg.message)[0]
const content = JSON.stringify(msg.message)
const chats = (M.mtype === 'conversation' && msg.message.conversation) ? msg.message.conversation : (M.mtype == 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (M.mtype == 'documentMessage') && msg.message.documentMessage.caption ? msg.message.documentMessage.caption : (M.mtype == 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (M.mtype == 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (M.mtype == 'buttonsResponseMessage' && msg.message.buttonsResponseMessage.selectedButtonId) ? msg.message.buttonsResponseMessage.selectedButtonId : (M.mtype == 'templateButtonReplyMessage') && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : ""

var prefix = /^[°•π÷×¶∆£¢€¥®™✓=|~zZ+×_*!#%^&./\\©^]/.test(chats) ? chats.match(/^[°•π÷×¶∆£¢€¥®™✓=|~xzZ+×_*!#,|`÷?;:%^&./\\©^]/gi) : ''	  

const command = chats.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = chats.trim().split(/ +/).slice(1)

//const command = chats.toLowerCase().split(' ')[0] || ''
const isGroup = msg.key.remoteJid.endsWith('@g.us')
const sender = isGroup ? (msg.key.participant ? msg.key.participant : msg.participant) : msg.key.remoteJid
const pushname = msg.pushName || "No Name"
const isCmd = command.startsWith(prefix)
const run = process.uptime()
const q = args.join(" ")
const body = chats.startsWith(prefix) ? chats : ''
const botNumber = dasha.user.id.split(':')[0] + '@s.whatsapp.net'
const groupMetadata = isGroup ? await dasha.groupMetadata(from) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const groupId = isGroup ? groupMetadata.id : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
const isGroupAdmins = groupAdmins.includes(sender) || false
const isOwner = ownerNumber.includes(sender)
const isNumber = x => typeof x === 'number' && !isNaN(x)
const mentionUser = [...new Set([...(m.mentionedJid || []), ...(M.quoted ? [M.quoted.sender] : [])])]

const isUrl = (uri) => {
return uri.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
}

const jsonformat = (json) => {
return JSON.stringify(json, null, 2)
}


const antibot = M.isBaileys
if(antibot === true)return
const quoted = M.quoted ? M.quoted : M
const mime = (quoted.msg || quoted).mimetype || '' 
const isMedia = /image|video|sticker|audio/.test(mime)

const isWebp = (M.mtype === 'imageMessage' || M.mtype === 'videoMessage')
const isImage = (M.mtype == 'imageMessage')
const isVideo = (M.mtype == 'videoMessage')
const isSticker = (M.mtype == 'stickerMessage')
const isQuotedMsg = (M.mtype == 'extendedTextMessage')
const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
const isQuotedAudio = isQuotedMsg ? content.includes('audioMessage') ? true : false : false
const isQuotedDocument = isQuotedMsg ? content.includes('documentMessage') ? true : false : false
const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
const isQuotedSticker = isQuotedMsg ? content.includes('stickerMessage') ? true : false : false


if(setting.Mode === 'Self'){
if (!isOwner) return 
}

function parseMention(text) {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}


// DATABASE
const _0x4363e7=_0x3930;function _0x3930(_0x787b9e,_0xd6950a){const _0x311fed=_0x311f();return _0x3930=function(_0x393051,_0x52e614){_0x393051=_0x393051-0x68;let _0x48c2a1=_0x311fed[_0x393051];return _0x48c2a1;},_0x3930(_0x787b9e,_0xd6950a);}(function(_0x48a7cc,_0xdd92a){const _0x327d36=_0x3930,_0x20f8f3=_0x48a7cc();while(!![]){try{const _0x2eea72=-parseInt(_0x327d36(0x84))/0x1+parseInt(_0x327d36(0x85))/0x2+parseInt(_0x327d36(0x82))/0x3*(-parseInt(_0x327d36(0x7a))/0x4)+-parseInt(_0x327d36(0x78))/0x5*(-parseInt(_0x327d36(0x6c))/0x6)+parseInt(_0x327d36(0x83))/0x7*(parseInt(_0x327d36(0x6a))/0x8)+-parseInt(_0x327d36(0x7f))/0x9*(-parseInt(_0x327d36(0x80))/0xa)+parseInt(_0x327d36(0x70))/0xb*(-parseInt(_0x327d36(0x6d))/0xc);if(_0x2eea72===_0xdd92a)break;else _0x20f8f3['push'](_0x20f8f3['shift']());}catch(_0x55b6f7){_0x20f8f3['push'](_0x20f8f3['shift']());}}}(_0x311f,0x770b5));function _0x311f(){const _0x1df5e6=['chats','settings','antispam','27vwguIP','1950180BGipZm','available','3MpZzwM','5473433LVSfNz','137058ErdJhY','715372AjpEfn','antidelete','composing','setPromote','log','setDemote','users','8CkovPP','setLeave','3990378VhqxSi','9804EDnBna','setWelcome','data','21274fpvKfE','antionce','restrict','object','recording','mute','afkTime','sender','5VKKrId','afkReason','739924KjJQQA','chat'];_0x311f=function(){return _0x1df5e6;};return _0x311f();}try{let users=global['db'][_0x4363e7(0x6f)][_0x4363e7(0x69)][M[_0x4363e7(0x77)]];if(typeof users!==_0x4363e7(0x73))global['db'][_0x4363e7(0x6f)][_0x4363e7(0x69)][M[_0x4363e7(0x77)]]={};if(users){if(!isNumber(users[_0x4363e7(0x76)]))users[_0x4363e7(0x76)]=-0x1;if(!('banned'in users))users['banned']=![];if(!(_0x4363e7(0x79)in users))users[_0x4363e7(0x79)]='';}else global['db']['data'][_0x4363e7(0x69)][M[_0x4363e7(0x77)]]={'afkTime':-0x1,'banned':![],'afkReason':''};let chats=global['db'][_0x4363e7(0x6f)][_0x4363e7(0x7c)][M['chat']];if(typeof chats!==_0x4363e7(0x73))global['db'][_0x4363e7(0x6f)][_0x4363e7(0x7c)][M['chat']]={};if(chats){if(!('antionce'in chats))chats[_0x4363e7(0x71)]=!![];if(!(_0x4363e7(0x75)in chats))chats[_0x4363e7(0x75)]=![];if(!('restrict'in chats))chats[_0x4363e7(0x72)]=![];if(!(_0x4363e7(0x7e)in chats))chats[_0x4363e7(0x7e)]=!![];if(!(_0x4363e7(0x86)in chats))chats[_0x4363e7(0x86)]=![];if(!(_0x4363e7(0x68)in chats))chats[_0x4363e7(0x68)]='';if(!('setPromote'in chats))chats[_0x4363e7(0x88)]='';if(!(_0x4363e7(0x6e)in chats))chats[_0x4363e7(0x6e)]='';if(!('setLeave'in chats))chats[_0x4363e7(0x6b)]='';}else global['db'][_0x4363e7(0x6f)][_0x4363e7(0x7c)][M[_0x4363e7(0x7b)]]={'antionce':![],'mute':![],'restrict':![],'antispam':![],'antidelete':![],'setDemote':'','setPromote':'','setWelcome':'','setLeave':''};let settings=global['db'][_0x4363e7(0x6f)][_0x4363e7(0x7d)][botNumber];if(typeof settings!==_0x4363e7(0x73))global['db'][_0x4363e7(0x6f)][_0x4363e7(0x7d)][botNumber]={};if(settings){if(!('available'in settings))settings[_0x4363e7(0x81)]=![];if(!(_0x4363e7(0x87)in settings))settings[_0x4363e7(0x87)]=![];if(!(_0x4363e7(0x74)in settings))settings[_0x4363e7(0x74)]=![];}else global['db']['data'][_0x4363e7(0x7d)][botNumber]={'available':![],'composing':![],'recording':![]};}catch(_0x216820){console[_0x4363e7(0x89)](_0x216820);}


// STATUS BOT
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {

cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
return cpu
})
const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})

function _0x5589(_0x40478f,_0x5312c9){const _0x493e42=_0x493e();return _0x5589=function(_0x558994,_0x2a9645){_0x558994=_0x558994-0x77;let _0x39a255=_0x493e42[_0x558994];return _0x39a255;},_0x5589(_0x40478f,_0x5312c9);}(function(_0x3b304b,_0x1467e2){const _0x44ca8c=_0x5589,_0x545c45=_0x3b304b();while(!![]){try{const _0x5255e0=-parseInt(_0x44ca8c(0x78))/0x1+parseInt(_0x44ca8c(0x7e))/0x2+-parseInt(_0x44ca8c(0x80))/0x3*(parseInt(_0x44ca8c(0x85))/0x4)+-parseInt(_0x44ca8c(0x77))/0x5*(parseInt(_0x44ca8c(0x81))/0x6)+-parseInt(_0x44ca8c(0x86))/0x7+parseInt(_0x44ca8c(0x79))/0x8*(-parseInt(_0x44ca8c(0x7f))/0x9)+parseInt(_0x44ca8c(0x7a))/0xa;if(_0x5255e0===_0x1467e2)break;else _0x545c45['push'](_0x545c45['shift']());}catch(_0x135d08){_0x545c45['push'](_0x545c45['shift']());}}}(_0x493e,0x6bcf7));function _0x493e(){const _0x5a08bb=['replace','split','671566NnpmHl','219411duooOz','2991GCqdMC','78wvJoWo','application','mimetype','concat','872SzrwYB','3589691QMQWxj','msg','328135SqiSgZ','1304rWbzYj','48QDDmti','18366960sYkFaB','document'];_0x493e=function(){return _0x5a08bb;};return _0x493e();}const downloadMediaMessage=async _0x345908=>{const _0x39f944=_0x5589;let _0x553c4f=(_0x345908[_0x39f944(0x87)]||_0x345908)[_0x39f944(0x83)]||'',_0x2e12dd=_0x553c4f[_0x39f944(0x7d)]('/')[0x0][_0x39f944(0x7c)](_0x39f944(0x82),_0x39f944(0x7b))?_0x553c4f[_0x39f944(0x7d)]('/')[0x0]['replace'](_0x39f944(0x82),_0x39f944(0x7b)):_0x553c4f['split']('/')[0x0],_0x40f08a=_0x553c4f[_0x39f944(0x7d)]('/')[0x1];const _0x19031a=await downloadContentFromMessage(_0x345908,_0x2e12dd);let _0x40abd1=Buffer['from']([]);for await(const _0x344b2e of _0x19031a){_0x40abd1=Buffer[_0x39f944(0x84)]([_0x40abd1,_0x344b2e]);}return _0x40abd1;};

const reply = (teks, men) => {
 return dasha.sendMessage(from, { text: teks, mentions: men ? men : [] }, { quoted: msg })
}

const replyNtag = (teks, buffer = fs.readFileSync(setting.pathImg)) => {
dasha.sendMessage(from, { text: teks,jpegThumbnail: buffer, mentions: parseMention(teks) }, { quoted: msg })
}

const textImg = (teks, buffer = fs.readFileSync(setting.pathImg), mess, men) => {
 return dasha.sendMessage(from, { text: teks, jpegThumbnail: buffer, mention: men ? men : [] }, { quoted: mess ? mess : msg })
}

const sendMess = (from, teks) => {
 return dasha.sendMessage(from, { text: teks })
}

const sendContact = (jid, numbers, name, quoted, men) => {
let number = numbers.replace(/[^0-9]/g, '')
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + name + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + number + ':+' + number + '\n'
+ 'END:VCARD'
return dasha.sendMessage(from, { contacts: { displayName: name, contacts: [{ vcard }] }, mentions : men ? men : []},{ quoted: quoted })
}

const sendFile = async (from, url, caption, msg, men) => {
let mime = '';
let res = await axios.head(url)
mime = res.headers['content-type']
if (mime.split("/")[1] === "gif") {
return dasha.sendMessage(from, { video: await convertGif(url), caption: caption, gifPlayback: true, mentions: men ? men : []}, {quoted: msg})
}
let type = mime.split("/")[0]+"Message"
if(mime.split("/")[0] === "image"){
return dasha.sendMessage(from, { image: await getBuffer(url), caption: caption, mentions: men ? men : []}, {quoted: msg})
} else if(mime.split("/")[0] === "video"){
return dasha.sendMessage(from, { video: await getBuffer(url), caption: caption, mentions: men ? men : []}, {quoted: msg})
} else if(mime.split("/")[0] === "audio"){
return dasha.sendMessage(from, { audio: await getBuffer(url), caption: caption, mentions: men ? men : [], mimetype: 'audio/mpeg'}, {quoted: msg })
} else {
return dasha.sendMessage(from, { document: await getBuffer(url), mimetype: mime, caption: caption, mentions: men ? men : []}, {quoted: msg })
}
}

//Please dont edit for urlbutton 
const buttonsDefault = [
{ callButton: {displayText: `Number Owner`, phoneNumber: `+628127668234`} },
{ urlButton: { displayText: `Github Bot`, url : `https://github.com/SenkuXZ`} },
{ quickReplyButton: { displayText: `Owner`, id: `${prefix}owner` } },
{ quickReplyButton: { displayText: `Tos`, id: `${prefix}rules` } }
]

const textTemplateButtons = (from, text, footer, buttons) => {
return dasha.sendMessage(from, { text: text, footer: footer, templateButtons: buttons })
}

dasha.sendReadReceipt(from, sender, [msg.key.id])


function _0xcece(){const _0x428da0=['172490EjMNpo','12CNZAhg','1087009lktsGa','2313678OlcBBH','𝑮𝒊𝒕𝒉𝒖𝒃\x20𝑶𝒘𝒏𝒆𝒓','𝑪𝒂𝒍𝒍\x20𝑶𝒘𝒏𝒆𝒓','message','𝑶𝒘𝒏𝒆𝒓','script','380903fROaRP','https://github.com/SenkuXZ','92974xSwKMF','1655630fiaHPA','donasi','99QnMICi','𝑺𝒄𝒓𝒊𝒑𝒕','𝑫𝒐𝒏𝒂𝒕𝒆','120NFlLIU','96996eIIwsx','relayMessage','4AzsqYs','160xMjFJj'];_0xcece=function(){return _0x428da0;};return _0xcece();}(function(_0x162f7c,_0x375991){const _0x2b6130=_0x3ceb,_0x21e758=_0x162f7c();while(!![]){try{const _0x5874e6=parseInt(_0x2b6130(0xe0))/0x1+parseInt(_0x2b6130(0xd3))/0x2*(parseInt(_0x2b6130(0xd8))/0x3)+-parseInt(_0x2b6130(0xd5))/0x4*(-parseInt(_0x2b6130(0xcd))/0x5)+parseInt(_0x2b6130(0xda))/0x6+-parseInt(_0x2b6130(0xcc))/0x7*(parseInt(_0x2b6130(0xd6))/0x8)+parseInt(_0x2b6130(0xcf))/0x9*(parseInt(_0x2b6130(0xd7))/0xa)+parseInt(_0x2b6130(0xd9))/0xb*(-parseInt(_0x2b6130(0xd2))/0xc);if(_0x5874e6===_0x375991)break;else _0x21e758['push'](_0x21e758['shift']());}catch(_0x2208b1){_0x21e758['push'](_0x21e758['shift']());}}}(_0xcece,0x378d7));function _0x3ceb(_0x43809e,_0x57d3bf){const _0xcecef7=_0xcece();return _0x3ceb=function(_0x3ceb89,_0x2ebf36){_0x3ceb89=_0x3ceb89-0xcc;let _0x2c5386=_0xcecef7[_0x3ceb89];return _0x2c5386;},_0x3ceb(_0x43809e,_0x57d3bf);}const sendButton5=async(_0x3c675e,_0x1c21d2,_0x3f7678,_0x126e06)=>{const _0xc27042=_0x3ceb;var _0x197cc3=await generateWAMessageFromContent(from,{'templateMessage':{'hydratedTemplate':{..._0x126e06[_0xc27042(0xdd)],'hydratedContentText':_0x1c21d2,'hydratedFooterText':_0x3f7678,'hydratedButtons':[{'urlButton':{'displayText':_0xc27042(0xdb),'url':_0xc27042(0xe1)}},{'callButton':{'displayText':_0xc27042(0xdc),'phoneNumber':'0895-1925-9294'}},{'quickReplyButton':{'displayText':_0xc27042(0xd1),'id':prefix+_0xc27042(0xce)}},{'quickReplyButton':{'displayText':_0xc27042(0xd0),'id':prefix+_0xc27042(0xdf)}},{'quickReplyButton':{'displayText':_0xc27042(0xde),'id':prefix+'owner'}}]}}},{});dasha[_0xc27042(0xd4)](_0x3c675e,_0x197cc3[_0xc27042(0xdd)],{'messageId':_0x197cc3['key']['id']});};



dasha.createMessage = async (jidnya, kontennya, optionnya) => {
return await generateWAMessage(jidnya, kontennya, {...optionnya,userJid: dasha.authState.creds.me.id,upload: dasha.waUploadToServer})
}


if (M.message) {
console.log(chalk.black(chalk.greenBright('[ PESAN ]')), chalk.bold(chalk.bgGreen(new Date)), chalk.black(chalk.whiteBright(chats || M.mtype)) + '\n' + chalk.greenBright('=> Dari'), chalk.bold(chalk.bgGreen(pushname)), chalk.yellow(M.sender) + '\n' + chalk.greenBright('=> Di'), chalk.bold(chalk.bgGreen(M.isGroup ? groupName : 'Private Chat', M.chat)))
}

if (isOwner){
if (chats.startsWith("> ")){
console.log(color('[EVAL]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
try {
let evaled = await eval(chats.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
textImg(`${evaled}`)
} catch (err) {
textImg(`${err}`)
}
} else if (chats.startsWith("$ ")){
console.log(color('[EXEC]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner aowkoakwoak`))
exec(chats.slice(2), (err, stdout) => {
if (err) return textImg(`${err}`)
if (stdout) textImg(`${stdout}`)
})
}
}




// BANNED
 if (db.data.users[M.sender].banned && isCmd) {
await replyNtag(`Maaf @${M.sender.split("@")[0]} Anda Telah Dibanned, Chat Owner Untuk Un Banned`)
return
}

	// Afk
try{
	for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
M.reply(`
Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
}

if (db.data.users[M.sender].afkTime > -1) {
let user = global.db.data.users[M.sender]
M.reply(`
Kamu berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''

}
} catch {}

function _0x2da3(_0x1766c6,_0x2f73ac){const _0x13bad6=_0x13ba();return _0x2da3=function(_0x2da368,_0x54b347){_0x2da368=_0x2da368-0x1bc;let _0x4e637e=_0x13bad6[_0x2da368];return _0x4e637e;},_0x2da3(_0x1766c6,_0x2f73ac);}const _0x3098da=_0x2da3;(function(_0x1b8807,_0x3e330e){const _0xd8494f=_0x2da3,_0x4f9d70=_0x1b8807();while(!![]){try{const _0x209068=parseInt(_0xd8494f(0x1bd))/0x1*(parseInt(_0xd8494f(0x1cd))/0x2)+-parseInt(_0xd8494f(0x1be))/0x3+-parseInt(_0xd8494f(0x1c9))/0x4+-parseInt(_0xd8494f(0x1ca))/0x5*(parseInt(_0xd8494f(0x1d1))/0x6)+parseInt(_0xd8494f(0x1cb))/0x7+parseInt(_0xd8494f(0x1c7))/0x8*(-parseInt(_0xd8494f(0x1d4))/0x9)+parseInt(_0xd8494f(0x1d3))/0xa;if(_0x209068===_0x3e330e)break;else _0x4f9d70['push'](_0x4f9d70['shift']());}catch(_0x42a130){_0x4f9d70['push'](_0x4f9d70['shift']());}}}(_0x13ba,0x4315d));if(isMedia&&M[_0x3098da(0x1c0)][_0x3098da(0x1c2)]&&M[_0x3098da(0x1c0)][_0x3098da(0x1c2)][_0x3098da(0x1c1)](_0x3098da(0x1c5))in global['db'][_0x3098da(0x1bc)]['cmd']){let hash=global['db'][_0x3098da(0x1bc)]['cmd'][M[_0x3098da(0x1c0)]['fileSha256'][_0x3098da(0x1c1)]('base64')],{q,mentionedJid}=hash,messages=await generateWAMessage(M[_0x3098da(0x1d2)],{'text':q,'mentions':mentionedJid},{'userJid':dasha['user']['id'],'quoted':M['quoted']&&M[_0x3098da(0x1c3)][_0x3098da(0x1c8)]});messages[_0x3098da(0x1d0)][_0x3098da(0x1cc)]=areJidsSameUser(M[_0x3098da(0x1bf)],dasha['user']['id']),messages[_0x3098da(0x1d0)]['id']=M[_0x3098da(0x1d0)]['id'],messages['pushName']=M[_0x3098da(0x1c4)];if(M[_0x3098da(0x1ce)])messages['participant']=M[_0x3098da(0x1bf)];let msg1={...msg,'messages':[proto[_0x3098da(0x1c6)]['fromObject'](messages)],'type':_0x3098da(0x1cf)};dasha['ev']['emit']('messages.upsert',msg1);}function _0x13ba(){const _0x504e39=['980308sNARJV','fromMe','32644weYkfu','isGroup','append','key','1958550nOVTXB','chat','8967270uXuldx','99LCiLUR','data','30ftBmMX','983763uLFwME','sender','msg','toString','fileSha256','quoted','pushName','base64','WebMessageInfo','108904Ekrrjp','fakeObj','1790244RKrtrX','5oNIXtH'];_0x13ba=function(){return _0x504e39;};return _0x13ba();}


dasha.tags = {

'downloader':'Downloader',
'owner':'Owner',
'group':'Group',
'bokep':'18+',

}


// COMMAND
switch (command) {
case 'setcmd': {
global.db.data.cmd = global.db.data.cmd || {}
if (!M.quoted)return reply(`Reply stiker!!\nExample : ${prefix + command} menu\n\n\n*Note : Tidak dapat disertai Prefix!!*`)
if (!M.quoted.fileSha256)return reply('SHA256 Hash Missing')
if (!q)return reply(`Untuk Command Apa?`)
let sticker = global.db.data.cmd
let hash = M.quoted.fileSha256.toString('base64')
if (sticker[hash] && sticker[hash].locked)return reply('You have no permission to change this sticker command')
sticker[hash] = {
    q,
    mentionedJid: M.mentionedJid,
    creator: M.sender,
    at: + new Date,
    locked: false,
}
reply(`Done!`)
}
break
   
case 'delcmd': {
let hash = M.quoted.fileSha256.toString('base64')
if (!hash)return reply(`Tidak ada hash`)
let sticker = global.db.data.cmd
if (sticker[hash] && sticker[hash].locked)return reply('You have no permission to delete this sticker command')
delete sticker[hash]
reply(`Done!`)
}
break

case 'listcmd': {
let teks = `
*List Hash*
Info: *bold* hash is Locked

*Hash :*
 ${Object.entries(global.db.data.cmd).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} 
*Command: ${value.q}*
*Creator : @${value.creator.split("@")[0]}*
*Locked : ${value.locked}*

`).join('\n')}
`.trim()
replyNtag(teks)
}
break

case 'lockcmd': {
if (!isOwner)return reply('Only Onwer..')
if (!M.quoted)return reply('Reply Pesan!')
if (!M.quoted.fileSha256)return reply('SHA256 Hash Missing')
let sticker = global.db.data.cmd
let hash = M.quoted.fileSha256.toString('base64')
if (!(hash in sticker))return reply('Hash not found in database')
sticker[hash].locked = !/^un/i.test(command)
M.reply('Done!')
}
break



case 'afk': {
let user = global.db.data.users[M.sender]
user.afkTime = + new Date
let text = q ? q : 'Tidak Ada!'
user.afkReason = text
replyNtag(`@${M.sender.split("@")[0]} Telah Afk dengan alasan ${text}`)
}
break


case 'rule': case 'rules':{
textImg(help.rules(prefix))
}
break

case 'tos': case 'donate': case 'donasi':{
textImg(help.tos(ownerNumber[0].split('@')[0], prefix))
}
break

case 'owner':
let vcard = 'BEGIN:VCARD\n'
    + 'VERSION:3.0\n' 
    + 'N:;Senkuu.;;;'
    + 'FN:Senkuu.\n'
    + 'ORG:Owner Bot;\n'
    + 'item1.TEL;type=CELL;type=VOICE;waid=6289519259294:+62 895-1925-9294\n' 
    + 'item1.X-ABLabel:Creator Bot\n'
    + 'item2.EMAIL;type=INTERNET:revalinof57@gmail.com\n'
    + 'item2.X-ABLabel:Email\n'
    + 'item3.URL:https://instagram.com\n'
    + 'item3.X-ABLabel:Instagram\n'
    + 'item4.ADR:;;Indonesia;;;;\n'
    + 'item4.X-ABLabel:Region\n'
    + 'END:VCARD'
dasha.sendMessage(from, { contacts: { displayName: 'Owner Bot', contacts: [{ vcard }] } }, { quoted: msg })
break

	
case 'del': case 'delete': case 'd': {
 if (!M.quoted.isBaileys)return textImg('Pesan tersebut bukan dikirim oleh bot!')
 dasha.sendMessage(M.chat, { delete: { remoteJid: M.chat, fromMe: true, id: M.quoted.id, participant: M.quoted.sender } })
}
break

case 'menu': case 'help': 
const _0x3fbf4d=_0x5d96;(function(_0x39916b,_0x5ef15e){const _0x3c1423=_0x5d96,_0x258ade=_0x39916b();while(!![]){try{const _0x310e9f=-parseInt(_0x3c1423(0x169))/0x1+-parseInt(_0x3c1423(0x16c))/0x2+parseInt(_0x3c1423(0x16a))/0x3+-parseInt(_0x3c1423(0x164))/0x4*(parseInt(_0x3c1423(0x166))/0x5)+-parseInt(_0x3c1423(0x162))/0x6+-parseInt(_0x3c1423(0x170))/0x7+parseInt(_0x3c1423(0x174))/0x8*(parseInt(_0x3c1423(0x171))/0x9);if(_0x310e9f===_0x5ef15e)break;else _0x258ade['push'](_0x258ade['shift']());}catch(_0x5e43c2){_0x258ade['push'](_0x258ade['shift']());}}}(_0x40b8,0x7140d));if(setting[_0x3fbf4d(0x16d)]=='ImgButton')sendButton5(from,help[_0x3fbf4d(0x16f)](time,salam,pushname,prefix),help[_0x3fbf4d(0x175)](),await dasha[_0x3fbf4d(0x161)](from,{'image':{'url':setting[_0x3fbf4d(0x173)],'caption':help[_0x3fbf4d(0x16f)](time,salam,pushname,prefix)}}));else{if(setting[_0x3fbf4d(0x16d)]==_0x3fbf4d(0x16e))sendButton5(from,help[_0x3fbf4d(0x16f)](time,salam,pushname,prefix),help['contri'](),await dasha[_0x3fbf4d(0x161)](from,{'video':fs[_0x3fbf4d(0x165)]('./media/pathVideo.mp4'),'caption':help[_0x3fbf4d(0x16f)](time,salam,pushname,prefix),'gifPlayback':!![]}));else{if(setting[_0x3fbf4d(0x16d)]==_0x3fbf4d(0x172)){const template=generateWAMessageFromContent(from,proto[_0x3fbf4d(0x178)][_0x3fbf4d(0x179)]({'templateMessage':{'hydratedTemplate':{'locationMessage':{'degreesLatotitude':0x0,'degreesLongitude':0x0,'jpegThumbnail':fs['readFileSync']('./media/gambar.jpg')},'hydratedContentText':help[_0x3fbf4d(0x16f)](time,salam,pushname,prefix),'hydratedFooterText':_0x3fbf4d(0x176)+tanggal(new Date()),'hydratedButtons':[{'urlButton':{'displayText':_0x3fbf4d(0x163),'url':_0x3fbf4d(0x168)}},{'callButton':{'displayText':'Number\x20Phone\x20Owner','phoneNumber':'0895-1925-9294'}},{'quickReplyButton':{'displayText':_0x3fbf4d(0x177),'id':prefix+_0x3fbf4d(0x17a)}},{'quickReplyButton':{'displayText':'Script','id':prefix+'script'}}]}}}),{'userJid':from,'quoted':msg});return dasha['relayMessage'](from,template[_0x3fbf4d(0x167)],{'messageId':template[_0x3fbf4d(0x16b)]['id']});}}}function _0x5d96(_0x44ea97,_0x1e9af7){const _0x40b8f0=_0x40b8();return _0x5d96=function(_0x5d961c,_0x358a94){_0x5d961c=_0x5d961c-0x161;let _0x25741e=_0x40b8f0[_0x5d961c];return _0x25741e;},_0x5d96(_0x44ea97,_0x1e9af7);}function _0x40b8(){const _0x40d621=['modelMenu','GifButton','listMenu','118384NMyUSI','4383LFXFwG','LocButton','pathImg','24616HRQysp','contri','Library\x20:\x20Baileys-Md\x0aVersion\x20:\x201.0.8\x0aLanguage\x20:\x20Javascript\x0aAuthor\x20:\x20No\x20Author\x0aTanggal\x20:\x20','Contact\x20Owner','Message','fromObject','owner','createMessage','1646550OpbrKp','Github\x20Owner','80488XbuLXj','readFileSync','80BElfja','message','https://github.com/SenkuXZ','855877fKyOaP','1775049xtULEp','key','314262CLVQqx'];_0x40b8=function(){return _0x40d621;};return _0x40b8();}
break

case 'setmenu':{
if (!isOwner) return reply(mess.owner)
if(args.length === 1)return reply('Pilih gif / img / loc kak')
if (args[0].toLowerCase() === 'gif'){
setting.modelMenu = 'GifButton'
textImg('Done..')
} else if (args[0].toLowerCase() === 'img'){
setting.modelMenu = 'ImgButton'
textImg('Done..')
} else if (args[0].toLowerCase() === 'loc'){
setting.modelMenu = 'LocButton'
textImg('Done..')
}
}
break

case 'join': case 'joingc': {
if (!isOwner) return reply(mess.owner)
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('chat.whatsapp.com')) return textImg(mess.worngFormat)
let query = q.split('https://chat.whatsapp.com/')[1]
let data = await dasha.groupAcceptInvite(query)
await reply(jsonformat(data))
}
break

case 'setpp': case 'setppbot':
if (!isOwner) return reply(mess.owner)
if (isImage || isQuotedImage) {
let img = await dasha.downloadAndSaveMediaMessage(quoted)
await dasha.updateProfilePicture(botNumber, { url: img}).then(res => fs.unlinkSync(img))
await reply(mess.done)
} else {
reply(mess.worngFormat)
}
break

//Group Sistem
case 'revoke':
if (!isGroup) return reply(mess.group)
if (!isGroupAdmins) return reply(mess.admin)
if (!isBotGroupAdmins) return reply(mess.botAdmin)
let link = await dasha.groupRevokeInvite(from)
await textImg(help.ok() + `\n\n*New Link for ${groupName}* :\n https://chat.whatsapp.com/${link}`)
break

case 'leave':
if (!isGroup) return reply(mess.group)
if (!isGroupAdmins && !isOwner) return reply(mess.admin)
reply('Sayonara~ 👋').then(async res => await dasha.groupLeave(from))
break

case 'setwelcome': {
if (!M.isGroup)return reply(mess.group)
if (!isBotGroupAdmins)return reply(mess.botAdmin)
if (!isGroupAdmins)return reply(mess.admin)
if (!q)return reply(`Teksnya Mana? Contoh ${prefix + command} ${mess.example1}`)
global.db.data.chats[M.chat].setWelcome = q
reply('Succes Change Caption Welcome')
}
break

case 'cekwelcome':{
if (!M.isGroup)return reply(mess.group)
if(!isGroupAdmins && !isOwner)return
let chat = global.db.data.chats[from]
let text = chat.setWelcome ? chat.setWelcome : '*Selamat Datang Di Group @subject*\n─────────────────\n*Nama : @user*\n*Pada : @tanggal*\n*Jangan Lupa Baca Rules Group*\n─────────────────\n*@desc*'
textImg('*CEK CAPTION WELCOME*\n\n' + text)
}
break

case 'delwelcome':{
if (!M.isGroup)return reply(mess.group)
if(!isBotGroupAdmins && !isOwner)return
global.db.data.chats[from].setWelcome = ''
textImg('Done menghapus caption welcome!')
}
break
            
case 'setleave': {
if (!M.isGroup)return reply(mess.group)
if (!isBotGroupAdmins)return reply(mess.botAdmin)
if (!isGroupAdmins)return reply(mess.admin)
if (!q)return reply(`Teksnya Mana? Contoh ${prefix + command} ${mess.example2}`)
global.db.data.chats[M.chat].setLeave = q
reply('Succes Change Caption Leave')
}
break

case 'cekleave': case 'cekleft':{
if (!M.isGroup)return reply(mess.group)
if(!isGroupAdmins && !isOwner)return
let chat = global.db.data.chats[from]
let text = chat.setLeave ? chat.setLeave : '*Sayonara* 👋\n─────────────────\n*Nama : @user*\n*Pada : @tanggal*\n\nTelah Meninggalkan Group @subject'
textImg('*CEK CAPTION LEAVE*\n\n' + text)
}
break

case 'delleave': case 'delleft':{
if (!M.isGroup)return reply(mess.group)
if(!isBotGroupAdmins && !isOwner)return
global.db.data.chats[from].setLeave = ''
textImg('Done menghapus caption leave!')
}
break

case 'tagall': case 'infoall':
if (!isGroup) return reply(mess.group)
if (!isGroupAdmins && !isOwner) return reply(mess.admin)
let teks = `*Mention All\n*Message :  ${q ? q : 'Nothing'}*\n\n`
for (let mem of groupMembers) {
teks += `࿃➡️ @${mem.id.split('@')[0]}\n`
}
teks += `\n*${botName}*`
dasha.sendMessage(from, { text: teks, mentions: groupMembers.map(a => a.id) }, { quoted: msg })
break

case 'hidetag':
if (!isGroup) return reply(mess.group)
if (!isGroupAdmins && !isOwner) return reply(mess.admin)
dasha.sendMessage(from, { text : q ? q : '' , mentions: groupMembers.map(a => a.id)})
break

//Weebs
case 'anime':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Anime(q).then(async data => {
let txt = `*-------「 ANIME-SEARCH 」-------*\n\n`
for (let i of data) {
txt += `*Title :* ${i.judul}\n`
txt += `*Url :* ${i.link}\n-----------------------------------------------------\n`
}
await sendFile(from,data[0].thumbnail,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'character': case 'karakter':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Character(q).then(async data => {
let txt = `*---「 CHARACTER-SEARCH 」---*\n\n`
for (let i of data) {
txt += `*Character :* ${i.character}\n`
txt += `*Url :* ${i.link}\n-----------------------------------------------------\n`
}
await sendFile(from,data[0].thumbnail,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'manga':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Manga('naruto').then(async data => {
let txt = `*------「 MANGA-SEARCH 」------*\n\n`
for (let i of data) {
 txt += `*Title :* ${i.judul}\n`
 txt += `*Url :* ${i.link}\n-----------------------------------------------------\n`
}
await sendFile(from,data[0].thumbnail,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

//Misc
case 'film':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Film(q).then(async data => {
let txt = `*--------「 FILM-SEARCH 」--------*\n\n`
for (let i of data) {
txt += `*Title :* ${i.judul}\n`
txt += `*Type :* ${i.type}\n`
txt += `*Quality :* ${i.quality}\n`
txt += `*Upload :* ${i.upload}\n`
txt += `*Url :* ${i.link}\n-----------------------------------------------------\n`
}
await sendFile(from,data[0].thumb,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'pinterest': case 'pin':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Pinterest(q).then(async data => {
await sendFile(from,data.url,help.ok(),msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'wattpad':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Wattpad(q).then(async data => {
let txt = `*----「 WATTPAD-SEARCH 」----*\n\n`
for (let i of data) {
txt += `*Title :* ${i.judul}\n`
txt += `*Reads :* ${i.dibaca}\n`
txt += `*Voting :* ${i.divote}\n`
txt += `*Bab :* ${i.bab}\n`
txt += `*Time :* ${i.waktu}\n`
txt += `*Url :* ${i.url}\n`
txt += `*Description :* ${i.description}\n -----------------------------------------------------\n`
}
await sendFile(from,data[0].thumb,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'drakor':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Drakor(q).then(async data => {
let txt = `*-----「 DRAKOR-SEARCH 」-----*\n\n`
for (let i of data) {
txt += `*Title :* ${i.judul}\n`
txt += `*Years :* ${i.years}\n`
txt += `*Genre :* ${i.genre}\n`
txt += `*Url :* ${i.url}\n-----------------------------------------------------\n`
}
await sendFile(from,data[0].thumbnail,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'webtonsearch': case 'webtoon':
if (!q) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Webtoons(q).then(async data => {
let txt = `*------「 WEBTOONS-SEARCH 」------*\n\n`
for (let i of data) {
txt += `*Title :* ${i.judul}\n`
txt += `*Like :* ${i.like}\n`
txt += `*Creator :* ${i.creator}\n`
txt += `*Genre :* ${i.genre}\n`
txt += `*Url :* ${i.url}\n ----------------------------------------------------------\n`
}
await textImg(txt)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'tiktok':
if (!q) return reply(`Kirim perintah ${command} link`)
if (!isUrl(q)) return reply(mess.worngFormat)
if (!q.includes('tiktok')) return reply(mess.worngFormat)
reply('Loading...')
xfar.Tiktok(q).then( data => {
  dasha.sendMessage(from, {
 video: { url: data.medias[0].url },
 caption: `${data.title}\n\nKamu bisa mengubahnya menjadi Vidio Tanpa Watermark atau Audio, pencet tombol dibawah untuk mengubahnya!`,
 buttons: [{buttonId: `${prefix}ttnowm ${args[0]} ${sender}`, buttonText: { displayText: "No Watermark" }, type: 1 },
	   {buttonId: `${prefix}ttaudio ${args[0]} ${sender}`, buttonText: { displayText: "Audio" }, type: 1 }],
 footer: "Dasha - MD"
  }, { quoted: msg })
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break


case 'ttnowm':
if (!q) return reply(`Kirim perintah ${command} link`)
if (sender != args[1]) return reply('Button ini bukan untuk anda!!\nSilahkan request terlebih dahulu!!')
if (!isUrl(q)) return reply(mess.worngFormat)
if (!q.includes('tiktok')) return reply(mess.worngFormat)
reply('Loading...')
skrep.tiktokDownloader(args[0]).then( data => {
  dasha.sendMessage(from, { video: { url: data.nowm }}, { quoted: msg })
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'ttaudio':
if (!q) return reply(`Kirim perintah ${command} link`)
if (sender != args[1]) return reply('Button ini bukan untuk anda!!\nSilahkan request terlebih dahulu!!')
if (!isUrl(q)) return reply(mess.worngFormat)
if (!q.includes('tiktok')) return reply(mess.worngFormat)
reply('Loading...')
skrep.tiktokDownloader(args[0]).then( data => {
  dasha.sendMessage(from, { audio: { url: data.music.playUrl }, mimetype: 'audio/mp4' }, { quoted: msg })
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
	break


case 'tiktoknowm':
if (!q) return reply(`Kirim perintah ${command} link`)
if (!isUrl(q)) return reply(mess.worngFormat)
if (!q.includes('tiktok')) return reply(mess.worngFormat)
reply('Loading...')
skrep.tiktokDownloader(args[0]).then( data => {
  dasha.sendMessage(from, { video: { url: data.nowm }}, { quoted: msg })
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'tiktokaudio':
if (!q) return reply(`Kirim perintah ${command} link`)
if (!isUrl(q)) return reply(mess.worngFormat)
if (!q.includes('tiktok')) return reply(mess.worngFormat)
reply('Loading...')
skrep.tiktokDownloader(args[0]).then( data => {
  dasha.sendMessage(from, { audio: { url: data.music.playUrl }, mimetype: 'audio/mp4' }, { quoted: msg })
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
	break

case 'facebook': case 'fb': case 'fbdl': case 'facebookdl':
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('facebook.com') && !q.includes('fb.watch')) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Facebook(args[0]).then(async data => {
let txt = `*FACEBOOK DOWNLOADER*\n\n`
txt += `*Title :* ${data.title}\n`
txt += `* Type :* ${data.medias[0].extension}\n`
txt += `*Quality :* ${data.medias[0].quality}\n`
txt += `*Size :* ${data.medias[0].formattedSize}\n`
txt += `*Url :* ${data.url}`
sendFile(from,data.medias[0].url,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'twtdl': case 'twt': case 'twitterdl': case 'twitter':
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('twitter.com')) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Twitter(args[0]).then(async data => {
let txt = `*TWITTER DOWNLOADER*\n\n`
txt += `*Title :* ${data.title}\n`
txt += `*Quality :* ${data.medias[1].quality}\n`
txt += `*Size :* ${data.medias[1].formattedSize}\n`
txt += `*Url :* ${data.url}`
sendFile(from,data.medias[1].url,txt,msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'ig': case 'igdl': case 'instagram': case 'instagramdl':
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('instagram.com')) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Instagram(args[0]).then(async data => {
let txt = `*Instagram Downloader*\n\n`
txt += `*Title :* ${data.title}\n`
txt += `*Total File :* ${data.medias.length}\n`
txt += `*Url Source :* ${data.url}\n\n`
txt += `*Tunggu sebentar kak, media sedang di kirim..*`
await textImg(txt).then(async res => {
for (let i of data.medias) {
sendFile(from, i.url, '', res)
}
})
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'mp4': case 'ytmp4':
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('youtu.be') && !q.includes('youtube.com')) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Youtube(args[0]).then(async (data) => {
let txt = `*Youtube Video*\n\n`
txt += `*Quality : ${data.medias[1].quality}*\n`
txt += `*Type : ${data.medias[1].extension}*\n`
txt += `*Size : ${data.medias[1].formattedSize}*\n`
txt += `*Url Source : ${data.url}*\n\n`
txt += `*Tunggu sebentar kak, media sedang dikirim...*`
sendFile(from, data.thumbnail, txt, msg)
sendFile(from, data.medias[1].url, '', msg)

})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'mp3': case 'ytmp3':
if (!q) return textImg(mess.worngFormat)
if (!isUrl(q)) return textImg(mess.worngFormat)
if (!q.includes('youtu.be') && !q.includes('youtube.com')) return textImg(mess.worngFormat)
await textImg(mess.wait)
xfar.Youtube(args[0]).then(async (data) => {
let txt = `*Youtube Audio*\n\n`
txt += `*Quality :* ${data.medias[7].quality}\n`
txt += `*Type :* ${data.medias[7].extension}\n`
txt += `*Size :* ${data.medias[7].formattedSize}\n`
txt += `*Url Source :* ${data.url}\n\n`
txt += `*Tunggu sebentar kak, media sedang dikirim...*`
sendFile(from, data.thumbnail, txt, msg)
sendFile(from, data.medias[7].url, '', msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break


/* *********************************************************/

case 'sendbuffer':
try{
await textImg('Tunggu sebentar...')
sendFile(M.chat, isUrl(q)[0], '', M)
} catch (err){
await textImg(err)
console.log(err)
}
break

/* *********************************************************/
case 'playmp3':
if(!q)return textImg(`Example : ${command} Payung teduh`)
await textImg(mess.wait)
let yut3 = await yts(q)
xfar.Youtube(yut3.all[0].url).then(async (data) => {
let txt = `*YOUTUBE AUDIO*\n\n`
txt += `*Quality :* ${data.medias[7].quality}\n`
txt += `*Type :* ${data.medias[7].extension}\n`
txt += `*Size :* ${data.medias[7].formattedSize}\n`
txt += `*Url Source :* ${data.url}\n\n`
txt += `*Tunggu sebentar media sedang di kirim..*`
sendFile(from, data.thumbnail, txt, msg)
sendFile(from, data.medias[7].url, '', msg)
})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'playmp4':
if(!q)return textImg(`Example : ${command} Payung teduh`)
await textImg(mess.wait)
let yut4 = await yts(q)
xfar.Youtube(yut4.all[0].url).then(async (data) => {
let txt = `*YOUTUBE VIDEO*\n\n`
txt += `*Quality :* ${data.medias[1].quality}\n`
txt += `*Type :* ${data.medias[1].extension}\n`
txt += `*Size :* ${data.medias[1].formattedSize}\n`
txt += `*Url Source :* ${data.url}\n\n`
txt += `*Tunggu sebentar media sedang di kirim...*`
sendFile(from, data.thumbnail, txt, msg)
sendFile(from, data.medias[1].url, '', msg)

})
.catch((err) => {
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
})
break

case 'randomsurah':
fetchJson('https://api.zeks.me/api/randomquran?apikey=DashaBotWa').then(async result => {
let txt = `*Random Qur'an*\n\n`
txt += '*Nama  Surah: ' + result.result.nama + '*\n'
txt += '*Arti : ' + result.result.arti + '*\n'
txt += '*Ayat : ' + result.result.ayat + '*\n'
txt += '*Nomor : ' + result.result.nomor + '*\n'
txt += '*Diturunkan : ' + result.result.type + '*\n'
txt += '*Rukuk : ' + result.result.rukuk + '*\n'
txt += '*Urutan : ' + result.result.urut + '*'
await sendFile(from, result.result.audio, '', msg).then(async res => {
dasha.sendMessage(from,{text : txt}, {quoted : res})
})
})
break

case 'joox':{
if(!q) return textImg(`*Example : ${command} payung teduh*`)
fetchJson(`https://api.zeks.me/api/joox?apikey=DashaBotWa&q=${q}`).then(async result => {
let text = '*Joox Downloader*\n\n'
text += '*Judul : ' + result.data[0].judul + '*\n'
text += '*Artis : ' + result.data[0].artist + '*\n'
text += '*Album : ' + result.data[0].album + '*\n'
text += '*Size : ' + result.data[0].size + '*'
sendFile(from, result.data[0].thumb, text, msg)
sendFile(from, result.data[0].audio, text, msg)
})
}
break


case 'ytsearch':case 'yts':{
try{
if(!q)return textImg(`example : ${command} bocil epep`)
await textImg('Tunggu sebentar..')
let ytnya= await yts(q)
let textxx = '*YouTube Search*\n\n'
for(let i of ytnya.all){
textxx += '» Title : '+ i.title + '\n'
textxx += '» Url Sourche : '+ i.url + '\n'
textxx += '» Upload : '+ i.ago + '\n'
textxx += '» Duration : '+ i.timestamp + '\n'
textxx += '» Views: ' + i.views + '\n\n'
}
textxx += ''
sendFile(from, ytnya.all[0].thumbnail, textxx, msg)
} catch (err){
for (let x of ownerNumber) {
sendMess(x, `*[ ${command} Error ]*  \n\n` + err)
}
textImg(help.err())
}
}
break

case 'surah':
try{
if(!q)return textImg(`Example : ${command} al-fatihah`)
let t = 0
xfar.Surah(q).then(async data => {
let txt = `*Surah Al-Qur'an*\n\n`
for(let i of data){
txt += 'ayat  : ' + `${t+=1}` + '\n'
txt += 'Arab : ' + i.arab + '\n'
txt += 'Latin : ' + i.latin + '\n'
txt += 'Terjemah  : ' + i.translate + '\n\n'
}
txt += ''
textImg(txt)
}
)
} catch (err) {
console.log(err)
return textImg('Error, mungkin yang anda cari tidak ada!')
}
break

case 'ping': case 'speed':{
const timestamp = speed();
const latensi = speed() - timestamp 
const neww = performance.now()
const oldd = performance.now()
textImg(`
Kecepatan Respon ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_

${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}

_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`)
 
}
break

case 'runtime':{
textImg(`${runtime(run)}`)
}
break 

case 'tomp4': case 'tovideo': {
if (!/webp/.test(mime))return reply(`balas stiker dengan caption *${prefix + command}*`)
let media = await dasha.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await dasha.sendMessage(M.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' } }, { quoted: msg})
    await fs.unlinkSync(media)
}
break

case 'togif': {
if (!/webp/.test(mime))return reply(`balas stiker dengan caption *${prefix + command}*`)
let media = await dasha.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await dasha.sendMessage(M.chat, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, { quoted: msg })
    await fs.unlinkSync(media)
}
break

case 'take': case 'colong': case 'swm': case 'stickerwm': case 'wm': case 'exif': {
if (!quoted)return textImg(`Reply Media dengan caption ${prefix + command} Punya|Senkuu`)
let { writeExif } = require('../lib/exif')
let media = {}
media.mimetype = mime
media.data = await M.getMsgBuffer(quoted)
let encmedia = await writeExif(media, {packname: q.split("|")[0] ? q.split("|")[0] : global.packname,author: q.split("|")[1] ? q.split("|")[1] : global.author })
dasha.sendMessage(M.chat, { sticker: { url: encmedia } }, { quoted: msg})
await fs.unlinkSync(encmedia)
}
break

/**************** PLUGINS ***************/


case 'igstalk':
let igstalk = require('../plugins/igstalk')
igstalk(q, textImg, sendFile, sendMess, M)
break

case 'lirik':
let lirik = require('../plugins/lirik')
lirik(q , sendFile , M , textImg , sendMess)
break

case 'ghstalk': case 'ghsearch': case 'githubstalk':
let github = require('../plugins/github')
github(q, textImg, sendMess )
break

case 'infocovid': case 'covid':
let covid = require('../plugins/covid')
covid(textImg)
break

case 'suit':
let suit = require('../plugins/suit')
suit(q,reply,prefix)
break

case 'darkmeme':
let darkmeme = require('../plugins/darkmeme')
darkmeme(sendFile , M)
break

case 'calc': case 'kalkulator':
let calc = require('../plugins/calculator')
calc(M, dasha, q)
break

case 'namaninja':
let namaninja = require('../plugins/namaninja')
namaninja(q,M)
break


case 'group': case 'grup':
if (!isGroup) return reply(mess.group)
if (!isGroupAdmins && !isOwner) return reply(mess.admin)
let groupsettings = require('../plugins/groupSettings')
groupsettings(q, dasha, M)
break


case 's': case 'sticker': case 'stiker':
let stickers = require('../plugins/sticker')
stickers(textImg, quoted, mime, dasha, M)
break

case 'mode': case 'set': 
 if (!isOwner) return reply(mess.owner)
let mode = require('../plugins/mode')
mode(prefix, dasha, M)
break


case 'self':{
if (!isOwner) return reply(mess.owner)
setting.Mode = 'Self'
textImg('Done..')
}
break

case 'public':{
if (!isOwner) return reply(mess.owner)
setting.Mode = 'Public'
textImg('Done..')
}
break

case 'toimg':
let toimg = require('../plugins/toimg')
toimg(dasha, M, quoted, isQuotedSticker, textImg )
break

case 'play':
let play = require('../plugins/play')
play(q, textImg, prefix, M, dasha, sendMess)
break


case 'broadcast': case 'bcgc':
let bcgc = require('../plugins/broadcast')
bcgc(M , q , dasha, isOwner)
break


default:
}
} catch (err) {
console.log(color('[ERROR]', 'red'), err)
}
}
